BEGIN
  -- Call the procedure
   HCRS.PKG_LOAD_BIVV_MEDI_DATA.p_run_pricing_delta;
   COMMIT;
END;
/
