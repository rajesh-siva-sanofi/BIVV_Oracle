BEGIN
  -- Call the procedure
   BIVV.PKG_STG_MEDI.p_run_pricing_delta;
   COMMIT;
END;
/
