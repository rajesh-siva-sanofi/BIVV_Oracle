CREATE OR REPLACE VIEW BIVV_PUR_FINAL_RESULTS_VAL_V AS
WITH src AS (
   SELECT 
      p.prod_id_pri as ndc11
      ,TO_CHAR(cqh.calcqtrhdr_dt_start,'YYYY"Q"Q') AS qtr
      ,cq.rpu
      ,cqh.calcqtrhdr_dt_start
      ,cqh.calcqtrhdr_dt_end
      ,f.formula_name, f.formula_desc
      ,s.status_desc
      ,cq.calcqtr_num
      ,cq.calcqtr_num_prior
      ,cppt.cont_num
      ,c.cont_title
      ,c.cont_internal_id
      ,(SELECT COUNT(*) FROM bivvcars.adjitem ai WHERE ai.cont_num = c.cont_num
         AND ai.adjitm_dt_start = cqh.calcqtrhdr_dt_start) AS adjitems_cnt
   FROM
      bivvcars.calcqtr cq
      ,bivvcars.prod p
      ,bivvcars.calcqtrhdr cqh
      ,bivvcars.status s
      ,bivvcars.formula f
      ,bivvcars.cppt
      ,bivvcars.cont c
   WHERE 1=1
      AND cq.status_num = s.status_num
      AND cq.status_num = 2010 --Active
      AND p.prod_num  = cq.prod_num
      AND cqh.calcqtrhdr_num = cq.calcqtrhdr_num
      AND cq.formula_num = f.formula_num (+)
      AND cq.cppt_num = cppt.cppt_num
      AND cppt.cont_num = c.cont_num),
val AS (
   SELECT src.cont_num, src.ndc11, src.qtr, COUNT(*) AS cnt
   FROM src
   GROUP BY src.cont_num, src.ndc11, src.qtr)
SELECT 
   CASE 
      WHEN (SELECT cnt FROM val WHERE val.cont_num = src.cont_num AND val.ndc11 = src.ndc11 AND val.qtr = src.qtr) > 1 THEN 'ERR: Multiple URAs. Adjust query' 
      WHEN pm.hcrs_pgm_id IS NULL AND adjitems_cnt > 0 THEN 'ERR: Contract not mapped'
      WHEN pm.hcrs_pgm_id IS NULL AND adjitems_cnt = 0 THEN 'WARN: Contract not mapped, no claim lines exist, URAs won''t be loaded'
   ELSE 'OK' END AS val_msg
   ,DECODE(src.cont_num, 1, 1, pm.hcrs_pgm_id) AS pgm_id -- load Medicaid FDRL URAs under Alaska Fdrl program
   ,src.*
FROM src
   ,medi_pgms_map_v pm
WHERE src.cont_num = pm.cont_num (+)
   AND src.cont_internal_id NOT IN (SELECT cont_internal_id FROM bivv.bivv_cont_excl_v) -- exclude not needed contracts
;

CREATE OR REPLACE VIEW BIVV_PUR_FINAL_RESULTS_V AS
SELECT
   DISTINCT
   p.period_id, p.first_day_period AS per_begin_dt, p.last_day_period AS per_end_dt
   ,s.pgm_id -- load Medicaid FDRL URAs under Alaska Fdrl program
   ,SUBSTR(s.ndc11,1,5) AS ndc_lbl, SUBSTR(s.ndc11,6,4) AS ndc_prod, SUBSTR(s.ndc11,10,2) AS ndc_pckg
   ,s.rpu AS calc_amt, SYSDATE AS eff_dt, to_date('1/1/2100','mm/dd/yyyy') AS end_dt
   ,'BIVV' AS src_sys -- this is needed for HCRS.PUR_EVALUATE_V view
   ,s.calcqtr_num AS src_sys_unique_id
   ,s.cont_num, s.cont_title, s.cont_internal_id, s.formula_name
FROM bivv_pur_final_results_val_v s
   ,hcrs.period_t p
WHERE NVL(s.val_msg, 'OK') = 'OK'
   AND s.calcqtrhdr_dt_start = p.first_day_period;

--SELECT t.per_begin_dt, t.pgm_id, t.ndc_lbl, t.ndc_prod, t.ndc_pckg, COUNT(*)
--FROM bivv_pur_final_results_v t
--GROUP BY t.per_begin_dt, t.pgm_id, t.ndc_lbl, t.ndc_prod, t.ndc_pckg
--HAVING COUNT(*) > 1
--ORDER BY 1 DESC,2,3,4
