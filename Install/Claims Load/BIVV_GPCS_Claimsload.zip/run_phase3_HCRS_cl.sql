begin
  -- Call the procedure
  hcrs.pkg_load_bivv_medi_data.p_run_phase3 (a_clean_flg => 'Y');
end;
/