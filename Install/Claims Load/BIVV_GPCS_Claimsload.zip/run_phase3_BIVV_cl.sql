begin
  -- Call the procedure
  bivv.pkg_stg_medi.p_run_phase3 (a_trunc_flg => 'Y', a_valid_flg => 'N');
end;
/